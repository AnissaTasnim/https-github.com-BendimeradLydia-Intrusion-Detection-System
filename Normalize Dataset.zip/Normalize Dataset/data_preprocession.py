# -*- coding: utf-8 -*-
"""
@author: BENDIMERAD Lydia Sonia
"""

import pandas as pd
# importing required libraries for normalizing data
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
import numpy as np

#This function allows to change the labels of that dataset, normal is set to 0 and any type of attack is set to 1
def change_label(df):
  df.label.replace(['normal'],0,inplace=True)
  df.label.replace(['apache2','back','land','neptune','mailbomb','pod','processtable','smurf','teardrop',
                    'udpstorm','worm','ftp_write','guess_passwd','httptunnel','imap','multihop','named',
                    'phf','sendmail','snmpgetattack','snmpguess','spy','warezclient','warezmaster',
                    'xlock','xsnoop','ipsweep','mscan','nmap','portsweep','saint','satan','buffer_overflow',
                    'loadmodule','perl','ps','rootkit','sqlattack','xterm'],1,inplace=True)#Different type of attacks
 
# This function allows to normalize the numerical features of the dataset
std_scaler = StandardScaler()
def normalization(df,col):
  for i in col:
    arr = df[i]
    arr = np.array(arr)
    df[i] = std_scaler.fit_transform(arr.reshape(len(arr),1))
  return df

#This function allows to numerize values of discrete columns
def normalization_discret(discrete_col,concat_df,columns):
    All_dict={} 
    i=1
    for feature in discrete_col :
        my_data=list(set(concat_df[feature]))
        my_dict = {}
        cpt=1
        for value in my_data:
            my_dict[value] = cpt
            cpt+=1
        All_dict[feature]=my_dict
    # print(All_dict)
    length=len(concat_df[concat_df.columns[0]])
    LTrain=[]
    for j in range(0,length):
        L=[]
        i=0
        for feature in columns:
            if feature in discrete_col :
                L.append(All_dict[feature][concat_df.iloc[j,i]])
            else:
                L.append(concat_df.iloc[j,i])
            i+=1
        LTrain.append(L)      
    return LTrain

#This is the main function that Normalize the NSDL-KDD dataset
def Process_Dataset(folderName,trainFile,testFile):
    columns_name=["duration","protocol_type","service","flag","src_bytes",
        "dst_bytes","land","wrong_fragment","urgent","hot","num_failed_logins",
        "logged_in","num_compromised","root_shell","su_attempted","num_root",
        "num_file_creations","num_shells","num_access_files","num_outbound_cmds",
        "is_host_login","is_guest_login","count","srv_count","serror_rate",
        "srv_serror_rate","rerror_rate","srv_rerror_rate","same_srv_rate",
        "diff_srv_rate","srv_diff_host_rate","dst_host_count","dst_host_srv_count",
        "dst_host_same_srv_rate","dst_host_diff_srv_rate","dst_host_same_src_port_rate",
        "dst_host_srv_diff_host_rate","dst_host_serror_rate","dst_host_srv_serror_rate",
        "dst_host_rerror_rate","dst_host_srv_rerror_rate","label","difficulty_level"]
    
    trainFrame= pd.read_csv(folderName+"/"+trainFile+".txt", header=None,names=columns_name)
    testFrame= pd.read_csv(folderName+"/"+testFile+".txt", header=None,names=columns_name)
    
    #Remove difficulty_level feature because this feature is not concidered in the original NSDL-KDD Dataset (See .arff dataset)
    trainFrame.drop(['difficulty_level'],axis=1,inplace=True)
    testFrame.drop(['difficulty_level'],axis=1,inplace=True)
    
    #Call the function that staderizes the labels (Target)
    change_label(trainFrame)
    change_label(testFrame)
    
    #Normalize the features to ensure that they have similar scales and ranges, which allows to have a more balances and accurate hyperplane
    # selecting numeric attributes columns from data
    numeric_col = ["duration","src_bytes",
                   "dst_bytes","hot","num_failed_logins",
                   "num_compromised","num_root",
                   "num_file_creations","num_access_files","num_outbound_cmds",
                   "count","srv_count","serror_rate",
                   "srv_serror_rate","rerror_rate","srv_rerror_rate","same_srv_rate",
                   "diff_srv_rate","srv_diff_host_rate","dst_host_count","dst_host_srv_count",
                   "dst_host_same_srv_rate","dst_host_diff_srv_rate","dst_host_same_src_port_rate",
                   "dst_host_srv_diff_host_rate","dst_host_serror_rate","dst_host_srv_serror_rate",
                   "dst_host_rerror_rate","dst_host_srv_rerror_rate"]
    length_test=len(trainFrame)
    length_train=len(testFrame)
    
    concat_df=pd.concat([trainFrame,testFrame])
    concat_df = normalization(concat_df.copy(),numeric_col)
    
    #Numerize the values of the discret columns
    discret_col = ['protocol_type','service','flag']
    LTrain=normalization_discret(discret_col,concat_df,columns_name[:-1])
        
    data = pd.DataFrame(LTrain, columns=columns_name[:-1])
        
    train_df=data[:length_test]
    test_df=data[length_test:]
    train_df.to_csv('NormalizedDataset/train.csv', index=False, sep=";")
    test_df.to_csv('NormalizedDataset/test.csv', index=False, sep=";")
      

folder = "NSL-KDD"
train= "KDDTrain+"
test="KDDTest+"

Process_Dataset(folder,train,test)
