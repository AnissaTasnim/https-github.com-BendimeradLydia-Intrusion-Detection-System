#include <random>
#include "Helpers.cpp"
#include <opencv2/core.hpp>
#include <opencv2/ml.hpp>


#define M_PI 3.141592653589793238463

/********Population********/
static double *randomSolution(int size){
    double *solution = (double*)malloc(sizeof(double)*size);
    for(int s=0;s<size;s++){
        solution[s]=(double)rand()/(RAND_MAX) +(rand()%100);
    }
    return solution;
};

static double *distanceSolution(int size,double *sol,int distance){
    double *solution = (double*)malloc(sizeof(double)*size);
    for(int s=0;s<size;s++){
        solution[s]=sol[s];
    }
    for(int i=0;i<distance;i++){
        int r=rand()%size;
//        solution[r]=((double)rand() / (double)RAND_MAX );
        solution[r]=(double)rand()/(RAND_MAX) +(rand()%100);
    }
    return solution;
};

static double *InitPopulation(int nbclan, int nbpod, int nborcas, int size) {
    double *population = (double*)malloc(sizeof(double)*size*nbclan*nbpod*nborcas);
    double **clansSolution=(double**)malloc(sizeof(double*)*nbclan*nbpod*nborcas);
    double **podSolution=(double**)malloc(sizeof(double*)*nbclan*nbpod*nborcas);
    for(int c=1;c<=nbclan;c++){
        clansSolution[c-1]= randomSolution(size);
        int k=size*((c-1)*nbpod*nborcas);
        for(int tmp=0;tmp<size;tmp++){
            population[k+tmp]=clansSolution[c-1][tmp];
        }
        for(int p=1;p<=nbpod;p++){
            podSolution[p-1]= distanceSolution(size,clansSolution[c-1],(size/3));
            k=size*((c-1)*nbpod*nborcas+(p-1)*nborcas);
            for(int tmp=0;tmp<size;tmp++){
                population[k+tmp]=podSolution[p-1][tmp];
            }
            int so=1;
            if(c==1 && p==1) so=3;
            if(p==1) so=2;
            for(int o=so;o<=nborcas;o++){
                int k=size*((c-1)*nbpod*nborcas+(p-1)*nborcas+(o-1));
                double *soltmp=distanceSolution(size,podSolution[p-1],(2*size/3));
                for(int tmp=0;tmp<size;tmp++){
                    population[k+tmp]=soltmp[tmp];
                }

            }
        }
    }
    return population;
};

static void displayPopulation(double *population,int size,int sizepop){
    for(int i=0;i<sizepop;i++){
        cout<<"Individu : "<<i<<" (";
        for(int j=0;j<size;j++){
            cout<<population[i*size+j]<<",";
        }
        cout<<")"<<endl;
    }
};

/********Evaluate Population************/
static double Evaluate( int exec,int param,int function, double *solution,double *Evaluation,double * E_Accuracy,double *E_Precision,double *E_recall,
                        int size,int maxsize,string Directory,int K)

{
    int rt_all=0;
    for(int index =0;index<maxsize;index ++){
        if(index%size==0) {
            double MaccuracyF=0,Merror=0,MrecallF=0, MprecisionF=0, MFARF=0,MfoneF=0,
                    STDaccuracyF=0,STDerror=0, STDrecallF=0, STDprecisionF=0, STDFARF=0, STDfoneF=0;
            double rt=crossValidation(function,solution,index,K,Directory,&MaccuracyF,&Merror,&MrecallF,&MprecisionF,&MFARF,&MfoneF,
                                      &STDaccuracyF,&STDerror,&STDrecallF,&STDprecisionF,&STDFARF,&STDfoneF);
            rt_all+=rt;
            Evaluation[(int)(index/size)]=MrecallF+(1-MFARF);
            E_Accuracy[(int)(index/size)]=MaccuracyF;
            E_Precision[(int)(index/size)]=MprecisionF;
            E_recall[(int)(index/size)]=MrecallF;
        }
    }
    return rt_all;
}
/*
static void Evaluate_CanBeUSed( int function, double *solution,double *Evaluation,
                      int size,int maxsize,string Directory,int K,
                      double *MaccuracyF,double *Merror,double *MrecallF,double *MprecisionF, double *MFARF,double *MfoneF,
                      double *STDaccuracyF,double *STDerror, double *STDrecallF, double *STDprecisionF, double *STDFARF, double *STDfoneF)

{
    for(int index =0;index<maxsize;index ++){
        if(index%size==0) {
            crossValidation(function,solution,index,K,Directory,MaccuracyF,Merror,MrecallF,MprecisionF,MFARF,MfoneF,
                            STDaccuracyF,STDerror,STDrecallF,STDprecisionF,STDFARF,STDfoneF);
            Evaluation[(int)(index/size)]=*MaccuracyF;//detectionR+(1-FalseAlarmR);
        }
    }
}*/

//Get the best solution
static int gettheBest(double* best,double *max,double *population, double *evaluation,
                      int begin, int end,int size,int stop) {
    //int clanPosition=(c-1)*nbpod*nborcas-1;
    max[stop] = evaluation[begin];
    int debut=stop*size;
    for(int c=0;c<size;c++){

        best[debut+c]=population[begin*size+c];
    }
    int bestpos=stop;
    for(int i=(begin+1);i<end;i++){
        if(evaluation[i]>max[stop]){
            bestpos=i;
            max[stop]=evaluation[i];
            for(int c=0;c<size;c++){
                best[debut+c]=population[begin+i*size+c];
            }
        }
    }
    return bestpos;
}


//Best from clan
static void gettheBestsC(double *best, double *population, double *Evaluation,
                         int nbclan,int nbpod,int nborcas, int N, int size) {

    for(int clan=0;clan<nbclan;clan++){
        int begin=clan;
        int beginpop=clan*size*nborcas*nbpod;
        double max=Evaluation[clan*N/nbclan];
        for(int c=0;c<size;c++){
            best[begin*size+c]=population[beginpop+c];

        }
        int end=(clan+1)*nborcas*nbpod;
        for(int i=(begin+1);i<end;i++){
            if(Evaluation[i]>max){
                max=Evaluation[i];
                for(int c=0;c<size;c++){
                    best[begin*size+c]=population[i*size+c];
                }
            }
        }
    }
}

//Best from Pod
static void gettheBestsP(double *best, double *population, double *Evaluation,
                         int nbclan,int nbpod,int nborcas, int N, int size) {

//        printf("nbpod *nbclan =%d\n", (nbpod * nbclan));
    int pod=0;
    for (pod = 0; pod < (nbpod * nbclan); pod++) {
//            printf("pod %d\n", pod);
        int begin = pod;
        int beginpop = pod * size * nborcas;
//            printf("pod*nborcas = %f\n", Evaluation[pod * nborcas]);
        double max = Evaluation[pod * nborcas];
        for (int c = 0; c < size; c++) {
            best[begin * size + c] = population[beginpop + c];
        }

        int end = (begin + 1) * nborcas;
        for (int i = (begin + 1); i < end; i++) {
            if (Evaluation[i] > max) {
                max = Evaluation[i];
                for (int c = 0; c < size; c++) {
                    best[begin * size + c] = population[i*size+c];
                }
            }
        }

    }
}

//Research functions
static void cooperatenew(double freq,double *cooperate,double *population,int nbclan,int nbpod,
                         int nborcas,int size,clock_t startTime,
                         int L,int T){
    int max=nbclan*nbpod;

    for(int index=0;index<max;index++){

        int beginPod = index;
        int endPod = (beginPod + 1);
        clock_t time_now = clock();
        double time = (double) (time_now - startTime) / (CLOCKS_PER_SEC);
        double S = L / freq;
        for (int i = size * beginPod; i < size * endPod; i++) {
            cooperate[i] = 0;

        }
        double max=1;
        for(int i=0;i<size;i++){
            int tmp2=(size*beginPod+i);
            for(int j=(0);j<(nborcas);j++){
                 cooperate[tmp2]+=(size)*(sin(2*M_PI*population[size*nborcas*beginPod+i+j*size])*
                                         cos(2*M_PI*time))/(nbpod);
            }


        }
    }

}

static void Intensification(double *clansbest,double *podsbest,double *velocity,double *population,
                            double *evaluation,
                            double *cooperation,int nborcas,int nbpod,int nbclan,
                            double *bestPop,int stop,double fmin,double fmax,int size){

    int N=nborcas*nbpod*nbclan*size;
    for(int index=0;index<N;index++){//Pour chaque orque
        if(index%size==0){
            int maxcoop=nbclan*nbpod*size;
            float random=((double)rand() / (double)RAND_MAX );

            if(random<0.5)
            {
                //wavewashing
                int numpod = index/size;
                //numpod = numpod - numpod%(nborcas);
                numpod=numpod/nborcas;
                int tmpp = numpod*size ;
                int numclan = index / (size);
                numclan = numclan -numclan%(nbpod*nborcas);
                numclan=numclan/(nbpod*nborcas);
//                int poscp=numclan*(nbpod-1)*size+tmpp;
                int poscp=numpod*size;
                for(int a=0;a<size;a++){
                    double beta=((double)rand() / (double)RAND_MAX );
                     population[index+a]=podsbest[tmpp+a]+ beta*cooperation[poscp+a];
                }
            }
            else{//echolocation
                double poddistance=0,clandistance=0,popdistance=0;
                for(int a=0;a<size;a++) {
                    int numpod = index/size;
                    //numpod = numpod - numpod%(nborcas);
                    numpod=numpod/nborcas;
                    int tmpp = numpod*size ;
                    int numclan = index / (size);
                    numclan = numclan -numclan%(nbpod*nborcas);
                    numclan=numclan/(nbpod*nborcas);
                    int tmpc = numclan * size ;

                    poddistance =podsbest[(tmpp + a)]-population[index+a];
                    clandistance =clansbest[(tmpc + a)]- population[index+a];
                    popdistance =bestPop[(size * stop + a)]-population[index+a];

                    double fpod = (fmax-fmin) * ((double)rand() / (double)RAND_MAX );;
                    double fclan =(fmax-fmin) * ((double)rand() / (double)RAND_MAX );;
                    double fpop = (fmax-fmin) *((double)rand() / (double)RAND_MAX );;

                    velocity[index+a] =  fmod((poddistance*fpod+
                                               clandistance*fclan+
                                               popdistance*fpop),1000000.0);
                    population[index+a]+=velocity[index+a];
                    population[index+a] = fmod(population[index+a],1000000.0);
//                    population[index+a] = 1000;//velocity[index+a];
                }
            }
        }
    }
};

static void diversificationSol(double *population,double *sol,int beginP,int beginC,int beginSol,int size){
    int xtmp=0;
    int cpt=0;
    int indexSol=beginSol;
    int i=0;

    while(indexSol<(beginSol+size)){
        double gamma =((double)rand() / (double)RAND_MAX );;
        double alpha =((double)rand() / (double)RAND_MAX );;
        sol[indexSol]= (population[beginC+i]+population[beginP+i])/2;
        indexSol++;
        i++;
    }
};


static void getWorstpod(int beginclan,int endclan,int nborcas,int size,double *evals,int *worstPod){
    double min=10000000000000000000000000000.0;
    *worstPod=beginclan;
    for(int i=beginclan;i<endclan;i=i+nborcas){
        double ME=0;
        for(int j=0;j<nborcas;j++){
            int pos=beginclan/size;
            ME+=evals[pos+j];
        }
        ME/=nborcas;
        if(ME<min){
            *worstPod=beginclan;
            min=ME;
        }
    }
};

static void diversification(double *evals,double *population,
                            int size,int nborcas,int nbpod, int nbclan,double *newSol)
{
    for(int index=0;index<nbclan;index++){
        int N=nbpod*nborcas*size,beginclan=index*N,endclan=beginclan+N;
         int beginWorstPod;
        getWorstpod(beginclan,endclan,nborcas,size,evals,&beginWorstPod);
        for(int no=0;no<nborcas;no++) {
            int randC=(endclan-beginclan-1)*((double)rand() / (double)RAND_MAX )+beginclan;
            int beginC=randC-(randC%size);
            int randP=(N*(nbclan-1))*((double)rand() / (double)RAND_MAX );
            int beginP=randP-(randP%size);
            int pp=0;
            do{
                randP=(N*(nbclan-1))*((double)rand() / (double)RAND_MAX );
                beginP=randP-(randP%size);
                pp++;
            }while((beginP==beginC) && (pp<5));

            diversificationSol(population,newSol,beginP,beginC,(index*size),size);

            for (int i = 0; i < size; i++) {
                population[beginWorstPod + i + size * no] = newSol[index*size+i];
            }

        }
    }
};