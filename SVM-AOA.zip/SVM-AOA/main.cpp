#include "AOA.cpp"
#include <opencv2/core.hpp>
#include <opencv2/ml.hpp>


using namespace cv;
using namespace cv::ml;
using namespace std;

//Dataset Directory
string Directory="../dataset IDS/";
//file of parameters
string parameters="../Parameters.csv";


string toStringSolution(double *bestSolutions,int bestStop,int size) {
    string solution = "(";
    for (int i = 0; i < size; i++) {
        solution += to_string(bestSolutions[bestStop * size + i]) + ",";
    }
    solution += to_string(bestSolutions[bestStop * size]);
    solution += ")";
    return solution;
}

void LaunchAOA(){

    int k=5;//the number of folds in cross validation
    /***********Read Dataset*********/
    int nbFeatures, nbLabels, nbInstancesTrain, nbInstanceTest;
    //Train Data
    Mat trainData, trainOutputData;
    read_csv(Directory, TRAIN, &trainData, &trainOutputData,
             &nbFeatures, &nbLabels, &nbInstancesTrain, &nbInstanceTest);
    //Test Data
    Mat testData;
    int *testOutputData = Malloc(int, (nbInstanceTest + 1));
    read_csv_test(Directory, TEST, &testData, testOutputData, &nbInstanceTest);

    int maximumExecutions=1;//previously set to 50;
    for(int nbexec=0;nbexec<maximumExecutions;nbexec++) {
        for (int empP = 0; empP < 4; empP++) {
            //AOA Parameters

            int nbclan, nbpod, nborcas, T, L, Fmin, Fmax, max_iter, Function;
            getParameters(parameters, empP, &nbclan, &nbpod, &nborcas, &max_iter,
                          &T, &L, &Fmin, &Fmax, &Function);
            /****Initialiaze artificial orcas****/
            int size = 1;// if Function is equal to SVM::LINEAR
            if (Function == SVM::POLY) size = 2;
            if (Function == SVM::RBF) size = 2;
            if (Function == SVM::CHI2) size = 2;

            int popsize = nbclan * nbpod * nborcas;
            int solutionsize = size * popsize;
            //velocity
            double *velocity = (double *) malloc(sizeof(double) * solutionsize);
            for (int tmp = 0; tmp < (solutionsize); tmp++) {
                velocity[tmp] = 0;
            }
            //Init Population
            double *population;
            population = InitPopulation(nbclan, nbpod, nborcas, size);
            /*****Evaluate population******/
            //Evaluate population
            double *Evaluation = (double *) malloc(sizeof(double) * popsize);
            double *Evaluation_accuracy = (double *) malloc(sizeof(double) * popsize);
            double *Evaluation_precision = (double *) malloc(sizeof(double) * popsize);
            double *Evaluation_Recall = (double *) malloc(sizeof(double) * popsize);
            Evaluate(nbexec,empP,Function, population, Evaluation,Evaluation_accuracy,Evaluation_precision,Evaluation_Recall,
                     size, solutionsize, Directory, k);

            //Cooperation
            int coopSize = nbclan * nbpod;
            //Save Best results
            double *bestFitnesses = (double *) malloc(sizeof(double) * (max_iter + 2));
            double *bestSolutions=(double *) malloc(sizeof(double) * size*(max_iter + 2));
            clock_t start_t = clock();
            int posbest=gettheBest(bestSolutions, bestFitnesses, population, Evaluation, 0,
                                   (popsize), size, 0);
            int bestStop = 0;
            int stop = 1;

            string solution=toStringSolution(bestSolutions,bestStop,size);
            //Save best Result of iteration 0
            writefile(nbexec,empP, bestFitnesses[bestStop], solution, 0,0,
                      Evaluation_accuracy[posbest], Evaluation_Recall[posbest], Evaluation_precision[posbest], -1, -1, -1, -1, 0);

            double executiontime_in=0;
            while ((stop < max_iter)) {
                //Wave washing
                double freq = (Fmax - Fmin) * ((double) rand() / (double) RAND_MAX) + Fmin;
                double *cooperation = (double *) malloc(sizeof(double) * size * coopSize);
                auto start = std::chrono::high_resolution_clock::now(); // get start time
                cooperatenew(freq, cooperation, population, nbclan, nbpod,
                             nborcas, size, start_t, L, T);
                //Intensification
                double *clansBest, *podsBest;
                clansBest=(double*)malloc(sizeof(double)*size*nbclan);
                podsBest=(double*)malloc(sizeof(double)*size*nbclan*nbpod);
                gettheBestsC(clansBest, population,Evaluation, nbclan, nbpod, nborcas,
                             (nbclan * nbpod * nborcas), size);
                gettheBestsP(podsBest, population,
                             Evaluation, nbclan, nbpod, nborcas,
                             (nbclan * nbpod * nborcas), size);
                Intensification(clansBest, podsBest,velocity, population,
                                Evaluation, cooperation, nborcas, nbpod, nbclan, bestSolutions, (stop - 1),
                                Fmin, Fmax, size);
                double *newSol=(double *)malloc(sizeof(double)*nbclan*size);
                diversification( Evaluation, population,
                                 size, nborcas, nbpod, nbclan, newSol);
                auto end = std::chrono::high_resolution_clock::now(); // get end time
                std::chrono::duration<double, std::milli> duration_ms = end - start; // calculate duration in milliseconds

                //Evaluate each orca through cross-validation process
                double rtE=Evaluate(nbexec,((stop+1)*(empP+1)),Function, population, Evaluation,Evaluation_accuracy,Evaluation_precision,Evaluation_Recall,
                                    size, solutionsize, Directory, k);
                executiontime_in +=(duration_ms.count()+rtE);
                int posbest=gettheBest(bestSolutions, bestFitnesses, population, Evaluation, 0,
                                       (popsize), size, stop);
                solution = toStringSolution(bestSolutions,stop,size);
                writefile(nbexec,empP, bestFitnesses[stop], solution, 0,(duration_ms.count()+rtE),
                          Evaluation_accuracy[posbest], Evaluation_Recall[posbest], Evaluation_precision[posbest],-1, -1, -1, -1, stop);

                if (bestFitnesses[stop - 1] <= bestFitnesses[stop]) {
                    bestStop = stop;
                }
                stop++;
                free(cooperation);
                free(clansBest);
                free(podsBest);
                free(newSol);
            }
            clock_t end_t = clock();
            double executiontime = (double) (end_t - start_t) / CLOCKS_PER_SEC;
            solution = toStringSolution(bestSolutions,bestStop,size);
            double accuracy,error,recall,fone,precision,FAR;
            //Validate and save the results of the bestsolution on test set
            double rtV=Validate(Function,bestSolutions,bestStop,trainData,trainOutputData,nbInstancesTrain,
                                testData,testOutputData,nbInstanceTest,
                                nbFeatures,nbLabels,
                                &accuracy,&error,&recall,&precision,&FAR,&fone);
            executiontime_in=rtV;
            writefile(nbexec,empP, bestFitnesses[bestStop], solution, executiontime,
                      executiontime_in,
                      accuracy,recall, precision, fone, error, FAR, bestStop, -1);

            free(population);
            free(velocity);
            free(Evaluation);
            free(bestFitnesses);
            free(bestSolutions);
        }
    }
}

int main() {

    srand( unsigned(time(0)));

    LaunchAOA();

    return 0;

}


