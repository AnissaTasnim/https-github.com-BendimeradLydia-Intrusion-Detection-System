#include <fstream>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <string>
#include<time.h>
#include <iostream>
#include <sstream>
#include <chrono>
#include <conio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <opencv2/core.hpp>
#include <opencv2/ml.hpp>

enum {TRAIN = 0 ,TEST = 1};

#define Malloc(type,n) (type *)malloc((n)*sizeof(type))


using namespace cv;
using namespace cv::ml;
using namespace std;



static string getfield(string line, int num,string delimiter){
    size_t pos=0;
    string token;
    int i=0;
    while((pos=line.find(delimiter)) != string::npos ){

        token = line.substr(0,pos);
        if(i==num){
            return token;
        }
        line.erase(0,pos+delimiter.length());
        i=i+1;

    }
    return line;
};

static void getParameters(string parameters,int nb, int *nbclan, int *nbpod, int *nborca, int *maxiter, int *T, int *L, int *fmin, int *fmax, int *function){

    ifstream myFile(parameters);

    // Make sure the file is open
    if(!myFile.is_open()) { cout << "Could not open file of parameters";}

    // Helper vars
    string line, colname;
    string val;
    int i=0;

    while(getline(myFile, line))
    {
        if(i==nb) {

            *nbclan=stoi(getfield(line,0,","));
            *nbpod=stoi(getfield(line,1,","));
            *nborca=stoi(getfield(line,2,","));
            *maxiter=stoi(getfield(line,3,","));
            *T=stoi(getfield(line,4,","));
            *L=stoi(getfield(line,5,","));
            *fmin=stoi(getfield(line,6,","));
            *fmax=stoi(getfield(line,7,","));
            if(getfield(line,8,",").compare("RBF")==0)
                *function= SVM::RBF;
            if(getfield(line,8,",").compare("POLY")==0)
                *function= SVM::POLY;
            if(getfield(line,8,",").compare("CHI")==0)
                *function= SVM::CHI2;
            if(getfield(line,8,",").compare("LIN")==0)
                *function= SVM::LINEAR;
            return ;
        }
        else if(i<nb)
            i++;
        else return ;
    }
    // Close file
    myFile.close();
}

static void writefile(int numexec,int numparam,double bestFitness,string bestSolution,double runningtime,double runningTimework,
                      double accuracy,double recall,double precision,double f_one_score,double error,double FAR,
                      int bestindex,int iteration)
{
    String OutputFolder="../Results/"+to_string(numexec)+"/all.txt";
    if(bestindex==-1){
        OutputFolder="../Results/"+to_string(numexec)+"/"+ to_string(numparam)+".txt";
        numparam=iteration;
    }
    ofstream MyWriteFile(OutputFolder,std::ios_base::app);
    MyWriteFile<<numparam<<","<< bestindex<<","<<bestFitness<<","<<accuracy<<","<<
               recall<<","<<precision<<","<<f_one_score<<","<<error<<","<<FAR<<","<<runningtime<<","<<runningTimework<<
               ","<<" Solution :"<<bestSolution<<"\n";
    MyWriteFile.close();
}

static void display_data(Mat data,Mat labels){
    for (int i = 0; i < data.rows; ++i)
    {
        cout<<"line "<<i<<endl;
        cout<<labels.at<int>(i,0)<<"---"<<" ";
        for (int k = 0; k < data.cols; ++k)
        {
            cout<<data.at<float>(i,k)<<" ; ";
        }
        cout<<endl;
    }
};

static void read_csv(string Directory,int type, Mat *trainingData, Mat *labels, int *nbFeatures,int *nbLabels,
                     int *nbITrain,int *nbITest) {

    ifstream infile(Directory+"Data.csv");
    if (!infile) {
        cout << "Failed to open file: Data.csv" << endl;
    }

    string line;
    getline(infile, line);
    int nbInstances = 0; //number of instances
    string filename;

    *nbITrain=stoi(getfield(line,0,";"));
    *nbITest=stoi(getfield(line,1,";"));
    if(type==0){
        nbInstances= *nbITrain;
        filename=Directory+"train.csv";
    }
    else{
        nbInstances = *nbITest;
        filename=Directory+"test.csv";
    }
    *nbFeatures = stoi(getfield(line,2,";"));; //number of features for each data vector
    *nbLabels = stoi(getfield(line,3,";"));; //number of features for each data vector

    int j=0;
    int cpt_ins=0;

    ifstream infile1(filename);

    if (!infile1) {
        cout << "Failed to open file: " << filename << endl;
    }
    *trainingData=Mat(nbInstances, (*nbFeatures), CV_32FC1);
    *labels=Mat(nbInstances, 1, CV_32SC1);
    int i=0;
    while (getline(infile1, line)) {
        stringstream ss(line);
        string field;
        int j=0;
        while (getline(ss, field, ';')) {
            if (!(field.find_first_not_of("0123456789e.-") == std::string::npos))
            {
                cout<<"i = "<<i<<" field = "<<field<<endl;
            }
            if(j==(*nbFeatures)) {
                labels->at<int>(i, 0) = stoi(field);
            }
            else{
                trainingData->at<float>(i, j) = stod(field);
                j++;
            }
        }
        i++;
    }
    infile1.close();
};

static void read_csv_fold(string Directory,int type, Mat *trainingData, Mat *labels,Mat *testData, int **testLabels,
                          int *nbFeatures,int *nbLabels,
                          int *trainrows,int *testrows,int k) {

    ifstream infile(Directory+"Data.csv");
    if (!infile) {
        cout << "Failed to open file: Data.csv" << endl;
    }

    string line;
    getline(infile, line);
    int nbInstances = 0; //number of instances
    string filename;

    double nbITrain=stoi(getfield(line,0,";"));
    double nbITest=stoi(getfield(line,1,";"));
    if(type==0){
        nbInstances= nbITrain;
        filename=Directory+"train.csv";
    }
    else{
        nbInstances = nbITest;
        filename=Directory+"test.csv";
    }
    *nbFeatures = stoi(getfield(line,2,";"));; //number of features for each data vector
    *nbLabels = stoi(getfield(line,3,";"));; //number of features for each data vector

    int nbInstanceFold=(nbInstances/k);
    for(int fold=0;fold<k;fold++){
        ifstream infile1(filename);
        int k1fold=nbInstances-nbInstanceFold;
        trainingData[fold]=Mat(k1fold, (*nbFeatures), CV_32FC1);
        labels[fold]=Mat(k1fold, 1, CV_32SC1);
        testData[fold]=Mat(nbInstanceFold, (*nbFeatures), CV_32FC1);
        testLabels[fold]=(int*) malloc(nbInstanceFold*sizeof(int));

        if (!infile1) {
            cout << "Failed to open file: " << filename << endl;
        }
        int itest=0,itrain=0,i=0;
        string field("");
        while (getline(infile1, line)) {
            int j=0;
            stringstream ss(line);
            while (getline(ss, field, ';')) {
                if (!(field.find_first_not_of("0123456789e.-") == std::string::npos))
                {
                    cout<<"i = "<<i<<" field = "<<field<<endl;
                }
                if((i>=(fold*nbInstanceFold))&&(i<((fold+1)*nbInstanceFold)) && (itest>=0) && (itest<nbInstanceFold)){
                    //Test fold
                    if(j==(*nbFeatures)) {
                        testLabels[fold][itest] = stoi(field);
                        itest++;//cette opération sera éffectuer une seule fois
                    }
                    else{
                        testData[fold].at<float>(itest, j) = stod(field);
                        j++;
                    }
                }
                else{
                    if(j==(*nbFeatures)) {
                        labels[fold].at<int>(itrain, 0) = stoi(field);
                        itrain++;
                    }
                    else{
                        trainingData[fold].at<float>(itrain, j) = stod(field);
                        j++;
                    }
                }
            }
            i++;
        }
        infile1.close();
    }
     *trainrows=nbInstanceFold*(k-1);
    *testrows=nbInstanceFold;

};

static void read_csv_test(string Directory,int type,Mat *trainingData,int *output,int *nbInstancetest)
{
    ifstream infile(Directory+"Data.csv");
    if (!infile) {
        cout << "Failed to open file: Data.csv" << endl;
    }

    string line;
    getline(infile, line);
    int nbInstances = 0; //number of instances
    string filename;
    if(type==0){
        nbInstances= stoi(getfield(line,0,";"));
        filename=Directory+"train.csv";
    }
    else{
        nbInstances = stoi(getfield(line,1,";"));
        *nbInstancetest=nbInstances;
        filename=Directory+"test.csv";
    }
    int nbFeatures = stoi(getfield(line,2,";"));; //number of features for each data vector

    int cpt_ins=0;
    ifstream infile1(filename);

    if (!infile1) {
        cout << "Failed to open file: " << filename << endl;
    }
    *trainingData=Mat(nbInstances, nbFeatures, CV_32FC1);
    int i=0;
    while (getline(infile1, line)) {
        stringstream ss(line);
        string field;
        int j=0;
        while (getline(ss, field, ';')) {
            if (!(field.find_first_not_of("0123456789e.-") == std::string::npos))
            {
                cout<<"i = "<<i<<" field = "<<field<<endl;
            }
            if(j==nbFeatures) {
                output[i] = stoi(field);
            }
            else{
                trainingData->at<float>(i, j) = stod(field);
                j++;
            }
        }
        i++;
    }
    output[i]=-1;
    infile1.close();
}


static void MakePrediction(Ptr<SVM> svm,Mat testData,int *test,int size) {

    for(int i=0;i<size;i++){
        Mat tmp(1,1,CV_32FC1);
        Mat dst(1, testData.cols, testData.type()); // declare destination Mat object with one row
        // Copy the first row of the source Mat object into the destination Mat object
        testData.row(i).copyTo(dst);
        svm->predict(dst, tmp);
        test[i]=(int)tmp.at<float>(0,0);
    }


}

static void Accuracy_Error(int *prediction,int *output,double *accuracy,double *error,int size){
    int correct = 0;
    int incorrect = 0;
    int total = 0;

    while(total!=size){
        if(prediction[total]==output[total])
            correct++;
        else
            incorrect++;
        total++;
    }
     *accuracy= (double) correct / (total-1) ;
    *error= (double) incorrect / (total-1) ;
};

static void CalculeLabel(int *prediction, int *output, int l, double *ri, double *pi, double *F,int size) {
    double TP=0,FN=0,FP=0,TN=0;
    int total=0;
    while(total!=size){
        if(prediction[total]==l && output[total]==l){
            TP++;
        }
        if(output[total]==l && prediction[total]!=l) {
            FN++;
        }
        if(output[total]!=l && prediction[total]==l) {
            FP++;
        }
        if(output[total]!=l && prediction[total]!=l) {
            TN++;
        }
        total++;
    }

    if(TP==0 && FN==0){
        *ri=-1;
//        cout<<"";//"Can not calculate the recall";
    }
    else
        *ri=TP/(TP+FN);//Detection Rate

    if(TP==0 && FP==0){
        *pi=-1;
//        cout<<"";//"Can not calculate the precision"<<endl;
    }
    else
        *pi=TP/(TP+FP);

    if(FP==0 && TP==0){
        *F=1;
//        cout<<"";//"Can not calculate the False Alarm Rate"<<endl;
    }
    else
        *F=FP/(FP+TN);

};

static void Recall_Precion_Fitness(int *prediction,int *output,int minlabel, int number_labels,
                                   double *recall,double *precision,double *fone,
                                   double *FAR,int size){
    double meanR=0,meanP=0,meanF=0,meanfone=0;
    for(int l=minlabel;l<(minlabel+number_labels);l++){
        double ri=0,pi=0,F=0;
        CalculeLabel(prediction,output,l,&ri,&pi,&F,size);
        meanR+=ri;
        meanP+=pi;
        meanF+=F;
        if( (pi+ri)!=0)
            meanfone+=2*pi*ri/(pi+ri);
        else
            meanfone+=0;
    }
    *recall= (double) meanR/number_labels ;
    *precision= (double) meanP/number_labels ;
    *FAR= (double) meanF/number_labels ;
    *fone= (double) meanfone/number_labels ;
};

static double Validate(int type,double *Solution,int index,Mat trainData,Mat trainOutputData,double nbInstancesTrain,
                     Mat testData,int *testOutputData,double nbInstanceTest, double nbFeatures,int nbLabels,
                     double *accuracy,double *error, double *recall, double *precision, double *FAR, double *fone){

    Ptr<SVM> svm = SVM::create();
    svm->setType(SVM::C_SVC);
    if(Solution[index]<0) Solution[index]=-1*(Solution[index]);
    if(Solution[index]==0) Solution[index]=(double)rand()/(RAND_MAX);
    if(type == SVM::LINEAR){
        svm->setKernel(SVM::LINEAR);
        svm->setC(Solution[index]);//All KERNEL
    }
    if(type == SVM::RBF){
        svm->setKernel(SVM::RBF);
        svm->setC(Solution[index]);
        if(Solution[index+1]<0) Solution[index+1]=-1*(Solution[index+1]);
        if(Solution[index+1]==0) Solution[index+1]=(double)rand()/(RAND_MAX);
        svm->setGamma(Solution[index+1]);//RBF KERNEL
    }
    if(type == SVM::POLY){
        svm->setKernel(SVM::POLY);
        svm->setC(Solution[index]);
        if(Solution[index+1]<0) Solution[index+1]=-1*(Solution[index+1]);
        if(Solution[index+1]==0) Solution[index+1]=(double)rand()/(RAND_MAX);

        svm->setDegree(Solution[index+1]);//Polynomial KERNEL
    }
    if(type == SVM::CHI2){
        svm->setKernel(SVM::CHI2);
        svm->setC(Solution[index]);
        if(Solution[index+1]<0) Solution[index+1]=-1*(Solution[index+1]);
        if(Solution[index+1]==0) Solution[index+1]=(double)rand()/(RAND_MAX);

        svm->setGamma(Solution[index+1]);//chi square KERNEL
    }
    //Train
    svm->train(trainData, ROW_SAMPLE, trainOutputData);
    int *predictedLabels=Malloc(int,nbInstanceTest);
    MakePrediction(svm,testData,predictedLabels,nbInstanceTest);
//
    svm.release();
    auto start = std::chrono::high_resolution_clock::now();
    *accuracy=0;
    *error=0;
    Accuracy_Error(predictedLabels,testOutputData,accuracy,error,nbInstanceTest);


    *recall=0;*precision=0;*fone=0;*FAR=0;
    Recall_Precion_Fitness(predictedLabels,testOutputData,0, nbLabels,
                           recall,precision,fone,FAR,nbInstanceTest);
    free(predictedLabels);
    auto end = std::chrono::high_resolution_clock::now(); // get end time
    std::chrono::duration<double, std::milli> duration_ms = end - start; // calculate duration in milliseconds
    return duration_ms.count();

};
static double calculateMean(double *data,int size) {
    double sum = 0;
    for (int i = 0; i <size ; i++) {
        sum += data[i];
    }
    return sum / size;
}

static double calculateStandardDeviation(double *data,int size,double mean) {
    double sum = 0;
    for (int i = 0; i < size; i++) {
        sum += pow(data[i] - mean, 2);
    }
    return sqrt(sum / size);
}

static double crossValidation(int type,double *Solution,int index,int k, string Directory,
                            double *MaccuracyF,double *Merror, double *MrecallF, double *MprecisionF, double *MFARF, double *MfoneF,
                            double *STDaccuracyF,double *STDerror, double *STDrecallF, double *STDprecisionF, double *STDFARF, double *STDfoneF){
    int nbFeatures,nbLabels;
     Mat *KtrainData=new Mat[k];
    Mat *KtrainOutputData=new Mat[k];
    Mat *KtestData=new Mat[k];
    int **KtestOutputData=(int **)malloc(k*sizeof(int*));
    int trainrows,testrows;
    read_csv_fold(Directory,TRAIN,KtrainData,KtrainOutputData,KtestData,KtestOutputData,
                  &nbFeatures,&nbLabels,&trainrows,&testrows,k);
    double *acc_array=Malloc(double,k+1),*err_array=Malloc(double,k+1),*r_array=Malloc(double,k+1),*p_array=Malloc(double,k+1),*far_array=Malloc(double,k+1),*fone_array=Malloc(double,k);
    double rt_all=0;
    for(int fold=0;fold<k;fold++){
        Mat train=KtrainData[fold];
        Mat outputtrain=KtrainOutputData[fold];
        Mat test=KtestData[fold];
        int *outputTest=KtestOutputData[fold];
        double accuracy=0,error=0,recall=0,fone=0,precision=0,FAR=0;
        double rt=Validate(type,Solution,index,train,outputtrain,trainrows,
                 test,outputTest,testrows,nbFeatures,nbLabels,
                 &accuracy,&error,&recall,&precision,&FAR,&fone);
        rt_all+=rt;
        acc_array[fold]=accuracy;
        err_array[fold]=error;
        r_array[fold]=recall;
        p_array[fold]=precision;
        far_array[fold]=FAR;
        fone_array[fold]=fone;
    }

    *MaccuracyF = calculateMean(acc_array,k);
    *STDaccuracyF = calculateStandardDeviation(acc_array,k,*MaccuracyF);
    *Merror =calculateMean(err_array,k);
    *STDerror = calculateStandardDeviation(err_array,k,*Merror);
    *MrecallF = calculateMean(r_array,k);
    *STDrecallF = calculateStandardDeviation(r_array,k,*MrecallF);
    *MprecisionF = calculateMean(p_array,k);
    *STDprecisionF = calculateStandardDeviation(p_array,k,*MprecisionF);
    *MFARF = calculateMean(far_array,k);
    *STDFARF = calculateStandardDeviation(far_array,k,*MFARF);
    *MfoneF = calculateMean(fone_array,k);
    *STDfoneF = calculateStandardDeviation(fone_array,k,*MfoneF);

    for(int ki=0;ki<k;ki++){
        KtrainData[ki].release();
        KtrainOutputData[ki].release();
        KtestData[ki].release();
    }

    free(KtestOutputData);
    free(acc_array);free(err_array);free(r_array);free(p_array);free(far_array);free(fone_array);

    return rt_all;
};

